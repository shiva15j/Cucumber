package exceptiondemo;

public class agemain {

	public static void main(String[] args) throws Exception {

		Vote.age();

	}

}
