package exceptiondemo;

public class demo1 {

	public static void main(String[] args) {

		String name = null;
		try {
			System.out.println(name.length());
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
